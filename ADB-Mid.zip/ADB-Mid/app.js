const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const Fuse = require('fuse.js');
const connectDb = require('./models/connectDb')
const fs = require('fs');
const path = require('path');

dotenv.config();

const Product = require('./models/product');
const Order = require('./models/order');
const Review = require('./models/review');
const User = require('./models/user');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const MONGO_URI = process.env.MONGO_URI

// ============== Routes ================

// 1) Product search (keyword + fuzzy + optional hybrid ranking)
app.get('/products/search', async (req, res) => {
  try {
    const q = req.query.query || '';
    const minPrice = parseFloat(req.query.minPrice) || 0;
    const maxPrice = parseFloat(req.query.maxPrice) || Number.MAX_SAFE_INTEGER;
    const category = req.query.category;
    const brand = req.query.brand;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const budget = req.query.budget ? parseFloat(req.query.budget) : null;
    const hybrid = req.query.hybrid === '1' || req.query.hybrid === 'true';

    const baseFilter = {
      price: { $gte: minPrice, $lte: maxPrice }
    };
    if (category) baseFilter.category = category;
    if (brand) baseFilter.brand = brand;

    let candidates;
    if (q.trim()) {
      // Try text search first
      try {
        candidates = await Product.find({
          ...baseFilter,
          $text: { $search: q }
        }, { score: { $meta: 'textScore' } }).sort({ score: { $meta: 'textScore' } }).lean();
      } catch (e) {
        candidates = await Product.find(baseFilter).lean();
      }

      // Fuse.js fuzzy refinement - inline map directly to candidates
      const fuseIndex = new Fuse(candidates, {
        keys: ['name', 'description', 'brand', 'category'],
        threshold: 0.5,
        includeScore: true,
      });

      candidates = fuseIndex.search(q).map(r => ({ ...r.item, similarity: 1 - (r.score || 0) }));
    } else {
      candidates = (await Product.find(baseFilter).lean()).map(p => ({ ...p, similarity: 1.0 }));
    }

    // Ranking
    const results = candidates.map(p => {
      const similarity = p.similarity !== undefined ? p.similarity : 0.5;
      const popularity = (p.purchaseCount || 0);
      const popScore = Math.log10((popularity || 0) + 1) / 5;
      let priceScore = 0;
      if (budget && p.price !== undefined) {
        const diff = Math.abs(p.price - budget);
        priceScore = Math.max(0, 1 - (diff / Math.max(budget, 1)));
      }
      const score = hybrid ? (0.4 * similarity + 0.4 * popScore + 0.2 * priceScore) : similarity;
      return { ...p, score };
    });

    results.sort((a, b) => (b.score - a.score) || ((b.purchaseCount || 0) - (a.purchaseCount || 0)));

    const start = (page - 1) * limit;
    const paged = results.slice(start, start + limit);

    res.json({ total: results.length, page, limit, results: paged });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 2) User orders
app.get('/users/:id/orders', async (req, res) => {
  try {
    const uid = req.params.id;
    const orders = await Order.find({ user: uid }).populate('items.product', 'name price brand category').sort({ createdAt: -1 }).lean();
    return res.json({ total: orders.length, orders });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
});

// 3) Product reviews
app.get('/products/:id/reviews', async (req, res) => {
  try {
    const pid = req.params.id;
    const reviews = await Review.find({ product: pid }).populate('user', 'name email').sort({ createdAt: -1 }).lean();
    return res.json({ total: reviews.length, reviews });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
});

// 4) Order detail
app.get('/orders/:id', async (req, res) => {
  try {
    const oid = req.params.id;
    const order = await Order.findById(oid).populate('user', 'name email location').populate('items.product', 'name price brand category').lean();
    if (!order) return res.status(404).json({ error: 'Order not found' });
    return res.json(order);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
});

// 5) Analytics: Top 5 products in last month grouped by category
app.get('/analytics/top-products', async (req, res) => {
  try {
    const now = new Date();
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());

    const pipeline = [
      { $match: { createdAt: { $gte: lastMonth } } },
      { $unwind: '$items' },
      { $group: { _id: '$items.product', totalQty: { $sum: '$items.quantity' } } },
      { $lookup: { from: 'products', localField: '_id', foreignField: '_id', as: 'product' } },
      { $unwind: '$product' },
      { $project: { productId: '$_id', name: '$product.name', category: '$product.category', totalQty: '$totalQty' } },
      { $sort: { category: 1, totalQty: -1 } },
      { $group: { _id: '$category', products: { $push: { productId: '$productId', name: '$name', totalQty: '$totalQty' } } } },
      { $project: { _id: 0, category: '$_id', products: { $slice: ['$products', 5] } } }
    ];

    const result = await Order.aggregate(pipeline);
    return res.json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
});

// 6) Admin seeding (uses the existing mongoose connection from this app)
app.post('/admin/seed', async (req, res) => {
  try {
    const confirm = req.query.confirm;
    if (confirm !== '1' && confirm !== 'true') {
      return res.status(400).json({ error: 'To run seeding call /admin/seed?confirm=1' });
    }

    const file = path.join(__dirname, 'seed', 'data.json');
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw);

    // Clear collections
    await Promise.all([
      Product.deleteMany({}),
      User.deleteMany({}),
      Order.deleteMany({}),
      Review.deleteMany({})
    ]);

    // Insert users
    const users = {};
    for (const u of data.users || []) {
      const doc = await User.create(u);
      users[doc.email] = doc;
    }

    // Insert products
    const products = {};
    for (const p of data.products || []) {
      const doc = await Product.create(p);
      products[doc.name] = doc;
    }

    // Insert orders
    for (const o of data.orders || []) {
      const user = users[o.userEmail];
      if (!user) continue;
      const items = [];
      let total = 0;
      for (const it of o.items || []) {
        const prod = products[it.productName];
        if (!prod) continue;
        items.push({ product: prod._id, quantity: it.quantity, price: prod.price });
        total += prod.price * it.quantity;
        await Product.findByIdAndUpdate(prod._id, { $inc: { purchaseCount: it.quantity } });
      }
      await Order.create({ user: user._id, items, totalCost: total, createdAt: o.createdAt ? new Date(o.createdAt) : undefined });
    }

    // Insert reviews
    for (const r of data.reviews || []) {
      const user = users[r.userEmail];
      const prod = products[r.productName];
      if (!user || !prod) continue;
      await Review.create({ user: user._id, product: prod._id, rating: r.rating, text: r.text, createdAt: r.createdAt ? new Date(r.createdAt) : undefined });
    }

    return res.json({ ok: true, message: 'Seeding complete' });
  } catch (err) {
    console.error('Seeding error:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Health
app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;

connectDb()
  .then(() => {
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch(err => {
    console.error('Failed to start server due to DB connection error.');
    process.exit(1);
  });
