Design notes (brief):

Schema choices:
- Products: standalone collection (referenced from orders and reviews). Contains basic searchable fields and a `purchaseCount` for popularity. Text index on name+description for keyword search. This avoids large product duplication and keeps product details normalized.

- Reviews: separate collection referencing `user` and `product`. Reviews can grow large and are read independently (pagination). Keeping them separate avoids inflating product documents.

- Orders: store order items as embedded subdocuments inside an Order document (items array with product reference, quantity, price). Orders are mostly read as historical records; embedding items makes the order self-contained.

- Users: standalone collection. Orders reference users by id.

Index suggestions:
- Product: text index on `name` + `description`.
- Product: indexes on `category`, `brand`, `price`, `purchaseCount`.
- Order: index on `createdAt` and `user`.

APIs designed:
- GET /products/search?query=&category=&brand=&minPrice=&maxPrice=&budget=&hybrid=1
  - Inputs: query string, filters. Outputs: paginated product list with scoring.
- GET /users/:id/orders
  - Returns: orders for user, populated product info per item.
- GET /products/:id/reviews
  - Returns: reviews for product with user info.
- GET /orders/:id
  - Returns: detailed order with user and product info.

Aggregation pipeline:
- match orders in last month, unwind items, group by product to sum quantities, lookup product to fetch category, group by category and gather top 5 products by quantity.


