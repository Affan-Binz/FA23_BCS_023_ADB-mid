const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce_sample';

async function check() {
  try {
    console.log('Using MONGO_URI=', MONGO_URI);
    // Use a short server selection timeout to fail fast if DB not running
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true, serverSelectionTimeoutMS: 3000 });
    console.log('MongoDB connected');
    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('MongoDB connection failed:');
    console.error(err.message || err);
    process.exit(2);
  }
}

check();

