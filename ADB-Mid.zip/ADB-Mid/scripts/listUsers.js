const mongoose = require('mongoose');
const User = require('../models/user');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce_sample';

async function run() {
  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  const users = await User.find().lean();
  console.log(JSON.stringify(users, null, 2));
  await mongoose.disconnect();
}

run().catch(err => { console.error(err); process.exit(1); });

