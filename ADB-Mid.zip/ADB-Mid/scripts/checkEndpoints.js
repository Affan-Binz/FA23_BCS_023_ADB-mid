const http = require('http');

function get(path) {
  return new Promise((resolve, reject) => {
    http.get({ host: 'localhost', port: 3000, path, timeout: 5000 }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ statusCode: res.statusCode, body: data }));
    }).on('error', reject).on('timeout', () => reject(new Error('timeout')));
  });
}

async function run() {
  try {
    console.log('Checking /health');
    console.log(await get('/health'));

    console.log('Checking /products/search?query=hp');
    console.log(await get('/products/search?query=hp'));

    console.log('Checking /analytics/top-products');
    console.log(await get('/analytics/top-products'));
  } catch (err) {
    console.error('Error checking endpoints:', err.message);
    process.exit(1);
  }
}

run();

