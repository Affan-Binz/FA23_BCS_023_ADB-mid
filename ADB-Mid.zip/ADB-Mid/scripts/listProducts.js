
const mongoose = require('mongoose');
const Product = require('../models/product');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce_sample';

async function run() {
  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  const products = await Product.find().lean();
  console.log(JSON.stringify(products.map(p => ({ _id: p._id, name: p.name, price: p.price })), null, 2));
  await mongoose.disconnect();
}

run().catch(err => { console.error(err); process.exit(1); });

