const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const Product = require('../models/product');
const User = require('../models/user');
const Order = require('../models/order');
const Review = require('../models/review');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce_sample';

async function seed() {
  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to MongoDB for seeding');

  const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'data.json'), 'utf8'));

  // Clear
  await Product.deleteMany({});
  await User.deleteMany({});
  await Order.deleteMany({});
  await Review.deleteMany({});

  // Insert users
  const users = {};
  for (const u of data.users) {
    const doc = await User.create(u);
    users[doc.email] = doc;
  }

  // Insert products
  const products = {};
  for (const p of data.products) {
    const doc = await Product.create(p);
    products[doc.name] = doc;
  }

  // Insert orders
  for (const o of data.orders) {
    const user = users[o.userEmail];
    if (!user) continue;
    const items = [];
    let total = 0;
    for (const it of o.items) {
      const prod = products[it.productName];
      if (!prod) continue;
      items.push({ product: prod._id, quantity: it.quantity, price: prod.price });
      total += prod.price * it.quantity;

      // update product purchaseCount
      await Product.findByIdAndUpdate(prod._id, { $inc: { purchaseCount: it.quantity } });
    }
    const doc = await Order.create({ user: user._id, items, totalCost: total, createdAt: new Date(o.createdAt) });
  }

  // Insert reviews
  for (const r of data.reviews) {
    const user = users[r.userEmail];
    const prod = products[r.productName];
    if (!user || !prod) continue;
    await Review.create({ user: user._id, product: prod._id, rating: r.rating, text: r.text, createdAt: new Date(r.createdAt) });
  }

  console.log('Seeding complete');
  await mongoose.disconnect();
}

seed().catch(err => { console.error(err); process.exit(1); });

