# E-commerce Backend Sample

This is a small Express + MongoDB sample implementing an e-commerce backend required for the assignment.

Features included:
- MongoDB schemas for Product, User, Order, Review (with justification in the assignment report)
- APIs:
  - GET /products/search?query=... (keyword + fuzzy search, optional hybrid ranking)
  - GET /users/:id/orders
  - GET /products/:id/reviews
  - GET /orders/:id
  - GET /analytics/top-products (aggregation pipeline)
- Seed script to populate sample data

Quick start
1. Install dependencies

```bash
npm install
```

2. Ensure MongoDB running locally or set `MONGO_URI` in `.env`.
3. Seed data

```bash
npm run seed
```

4. Start server

```bash
npm start
```

Endpoints
- GET /products/search?query=hp+lap&hybrid=1&budget=650 — supports keyword + fuzzy search and hybrid ranking when `hybrid=1`.
- GET /users/:id/orders — list orders for a user
- GET /products/:id/reviews — list reviews for a product
- GET /orders/:id — order detail
- GET /analytics/top-products — top 5 purchased products in last month grouped by category (aggregation pipeline)

Aggregation pipeline (Top 5 products per category in last month):
See `/analytics/top-products` implementation in `app.js` — it matches orders in last month, unwinds items, groups by product to sum quantities, looks up product documents to get category/name, then groups by category and slices top 5 products.

Indexes suggested:
- Text index on `products.name` and `products.description` for keyword search.
- Indexes on `products.price`, `products.category`, and compound indexes like `{ category: 1, price: 1 }` for price filtering.
- Index on `orders.createdAt` for date-range analytics.

Notes
- The search endpoint uses MongoDB text search and Fuse.js fuzzy search combined. For production with large datasets, consider using a dedicated search engine (Elasticsearch / OpenSearch) or MongoDB Atlas Search.


